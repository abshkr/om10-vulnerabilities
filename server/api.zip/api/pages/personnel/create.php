<?php
include_once '../../shared/header.php';

include_once '../../config/database.php';
include_once '../../objects/personnel.php';

Utilities::create("Personnel");
