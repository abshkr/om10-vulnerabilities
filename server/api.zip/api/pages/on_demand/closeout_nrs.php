<?php
// required headers
include_once '../../shared/header.php';

// include database and object files
include_once '../../config/database.php';
include_once '../../objects/on_demand.php';

Utilities::read('OndemandReport', "closeout_nrs", $filter = true);
