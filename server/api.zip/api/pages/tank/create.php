<?php
// required headers
include_once '../../shared/header.php'; 

include_once '../../config/database.php';
include_once '../../objects/tank.php';

Utilities::create('Tank');
