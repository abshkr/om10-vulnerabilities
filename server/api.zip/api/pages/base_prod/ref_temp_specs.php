<?php
// required headers
include_once '../../shared/header.php';

// include database and object files
include_once '../../config/database.php';
include_once '../../objects/ref_temp_spec.php';

Utilities::read('RefTempSpec');
