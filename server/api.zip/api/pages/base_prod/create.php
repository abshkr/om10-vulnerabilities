<?php
// required headers
include_once '../../shared/header.php';

include_once '../../config/database.php';
include_once '../../objects/base_product.php';

Utilities::create('BaseProduct');
